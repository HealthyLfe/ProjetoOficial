package com.example.healthylife6.classe

data class Exercicio(
    var exerId: String,
    var titulo: String,
    var tempo: String,
    var desc: String,
    var img: String
)