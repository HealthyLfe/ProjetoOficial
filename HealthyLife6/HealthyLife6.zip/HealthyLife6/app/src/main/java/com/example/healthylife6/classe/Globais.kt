package com.example.healthylife6.classe

var idRecSelecionado : String = ""

var idExerSelecionado : String = ""

var idReceitaAdm : String = ""

var idExercicioAdm : String = ""

var categoriaAdm: String = ""

var emailLogado: String = ""