package com.example.healthylife6.classe

data class Receita(
    var recId: String,
    var titulo: String,
    var ingrediente: String,
    var desc: String,
    var cat: String,
    var img: String)

