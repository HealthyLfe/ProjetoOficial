package com.example.healthylife6.classe

data class Usuario(
    var userId: String,
    var nome: String,
    var sexo: String,
    var idade: String,
    var peso: String,
    var altura: String,
    var email: String,
    var senha: String)